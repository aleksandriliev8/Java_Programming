package problem2;

import java.util.Scanner;

public class Palindrome {
    // main + Tab
    //psvm + Tab

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter five digit number:" );
        int number = input.nextInt();

        if(number >= 10_000 && number <= 99_999) {

        } else {
            System.out.println("The number is not five digits!");
        }
    }
}
